/* a comment / */
/* "not a string" */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <ctype.h>
#include <signal.h>
#include <time.h>
#include <wchar.h>

/*
    multiline comment
    comment
*/

int main()
{
    auto char* multi = "a multi"; /* and a comment !*/
}

/* A final comment for good measure /* /* /* */



